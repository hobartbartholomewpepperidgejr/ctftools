# ctftools
note!!!!! this program is designed to work best if ran _before_ your slugcat campaign has been started!!! this is due to some silly tickrate sync checking that works off of the time spent holding down the continue/new game button.

the "L" and "R" fields denote the time spent holding each key of the same title last.
set your controls in controls.txt!!! defaults are A, D, and END for left, right, and jump (select) inputs, respectively.
